package com.cg.SeleniumDemo;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;


public class SeleniumDemo {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		   System.setProperty("webdriver.chrome.driver", "C:\\selenium examples//chromedriver.exe");
		   WebDriver driver=new ChromeDriver();
	   driver.get("https://www.wikipedia.org/");
	   driver.findElement(By.xpath("//Input[@id='searchInput']")).sendKeys("india");
	   driver.findElement(By.xpath("//i[@class='sprite svg-search-icon']")).click();
	   driver.close();

	}

}
